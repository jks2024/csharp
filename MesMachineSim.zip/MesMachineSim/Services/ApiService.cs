using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using MesMachineSim.Models;
using MesMachineSim.Config;

namespace MesMachineSim.Services
{
  public class ApiService
  {
    private readonly HttpClient _httpClient; // 작명 규칙

    public ApiService()
    {
      _httpClient = new HttpClient
      {
        BaseAddress = new Uri(AppConfig.BaseUrl) // 객체 초기화자 문법
      };
    }
    // 작업 지시지 폴링 (Get)
    public async Task<WorkOrderDto?> PollWorkOrderAsync() 
    {
      try
      {
        var response = await _httpClient.GetAsync("machine/poll");
        if (response.StatusCode == System.Net.HttpStatusCode.OK)
        {
          return await response.Content.ReadFromJsonAsync<WorkOrderDto>();
        }
      } catch (Exception ex)
      {
        Console.WriteLine($"[Error] API 통신 실패: {ex.Message}");
      }
      return null;
    }
    // 실적 보고 (POST)
    public async Task<bool> ReportProductionAsync(ProductionReportDto report)
    {
      try
      {
        var response = await _httpClient.PostAsJsonAsync("machine/report", report);
        return response.IsSuccessStatusCode;
      } catch (Exception ex)
      {
        Console.WriteLine($"[Error] 실적 보고 실패: {ex.Message}");
        return false;
      }
    }
  }  
}