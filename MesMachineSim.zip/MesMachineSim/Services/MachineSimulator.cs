using System;
using System.Threading.Tasks;
using MesMachineSim.Models;
using MesMachineSim.Config;

namespace MesMachineSim.Services
{
  public class MachineSimulator
  {
    private readonly ApiService _apiService;
    private readonly Random _random = new Random();

    public MachineSimulator (ApiService apiService)
    {
      _apiService = apiService;
    }

    public async Task RunAsync()
    {
      Console.WriteLine($"🚀 설비 [{AppConfig.MachineId}] 가동을 시작합니다.");

      while (true)
      {
        Console.WriteLine("\n[Poller] 작업 지시를 확인 중...");
        var workOrder = await _apiService.PollWorkOrderAsync();

        if (workOrder != null)
        {
            await ProcessWorkOrder(workOrder);
        }
        else
        {
            Console.WriteLine("[-] 현재 할당된 작업이 없습니다.");
        }

        await Task.Delay(AppConfig.PollingIntervalMs);
      }
    }

    private async Task ProcessWorkOrder(WorkOrderDto order)
    {
      Console.ForegroundColor = ConsoleColor.Cyan;
      Console.WriteLine($"[Active] 작업 수주: {order.ProductCode} (목표: {order.TargetQty})");
      Console.ResetColor();

      // 생산 공정 시물레이션 (2초)
      await Task.Delay(2000);

      // 95% 확률로 양품(OK), 5% 확률로 불량(NG)
      bool isSuccess = _random.NextDouble() > 0.05;

      var report = new ProductionReportDto
      {
        OrderId = order.Id,
        MachineId = AppConfig.MachineId,
        Result = isSuccess ? "OK" : "NG",
        DefectCode = isSuccess ? null : "ERR-102" // 예: 치수 불량
      };

      bool reportResult = await _apiService.ReportProductionAsync(report);

      if (reportResult)
      {
        Console.ForegroundColor = isSuccess ? ConsoleColor.Green : ConsoleColor.Red;
        Console.WriteLine($"[Report] {order.ProductCode} 생산 결과: {report.Result}");
        Console.ResetColor();
      }
    }
  }
}
